# Taxi-fare-calculator
A google maps API based taxi fare calculator
* This project contains the code to query *Google Maps API* for distance measure.
* After the distance measurement, a taxi fare will be calculated and a stepped route can be displayed.
